package com.goavibes.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Teal = Color(0xFF087E8B)
private val DeepTeal = Color(0xFF07515B)
private val Sand = Color(0xFFFFF4DF)
private val Coral = Color(0xFFFF8066)
private val Ink = Color(0xFF18343A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoaVibesApp() }
    }
}

private enum class Tab { HOME, PLAN, BUDGET, CHECKLIST }

@Composable
private fun GoaVibesApp() {
    var tab by remember { mutableStateOf(Tab.HOME) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Coral, background = Sand, surface = Color.White)) {
        Scaffold(
            containerColor = Sand,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(tab == Tab.HOME, { tab = Tab.HOME }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(tab == Tab.PLAN, { tab = Tab.PLAN }, icon = { Icon(Icons.Default.Map, null) }, label = { Text("Plan") })
                    NavigationBarItem(tab == Tab.BUDGET, { tab = Tab.BUDGET }, icon = { Icon(Icons.Default.Payments, null) }, label = { Text("Budget") })
                    NavigationBarItem(tab == Tab.CHECKLIST, { tab = Tab.CHECKLIST }, icon = { Icon(Icons.Default.Checklist, null) }, label = { Text("Checklist") })
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    Tab.HOME -> HomeScreen()
                    Tab.PLAN -> PlanScreen()
                    Tab.BUDGET -> BudgetScreen()
                    Tab.CHECKLIST -> ChecklistScreen()
                }
            }
        }
    }
}

@Composable
private fun HomeScreen() {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("YOUR FRIENDS. YOUR BEACH. YOUR STORY.", color = Teal, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Goa Vibes", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                }
                Text("🌴", fontSize = 34.sp)
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(DeepTeal, Teal, Color(0xFF39B7B0))), RoundedCornerShape(26.dp)).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("THE COUNTDOWN IS ON", color = Color(0xFFBDECE8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Goa, here we come! 🌊", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Sunsets, beaches and unforgettable memories with your crew.", color = Color.White)
                Text("🏖 Beach days     🧑‍🤝‍🧑 Friends trip", color = Color.White)
            }
        }
        item {
            Text("TRIP SNAPSHOT", color = Teal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                MiniCard("👥", "Friends", "Your crew", Modifier.weight(1f))
                MiniCard("📍", "Destination", "Goa, India", Modifier.weight(1f))
                MiniCard("💰", "Budget", "Track it", Modifier.weight(1f))
            }
        }
        item {
            Text("THE CREW", color = Teal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CrewLine("😎", "Your friends", "Add your group members")
                    CrewLine("📱", "Stay connected", "Keep bookings and contacts handy")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE1D8))) {
                Text("☀️ Travel smart, party safe. Keep your ID, bookings and emergency contacts handy.", Modifier.padding(16.dp), color = Ink)
            }
        }
    }
}

@Composable
private fun MiniCard(emoji: String, title: String, sub: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(emoji, fontSize = 22.sp)
            Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(sub, color = Color.Gray, fontSize = 10.sp)
        }
    }
}

@Composable
private fun CrewLine(emoji: String, title: String, sub: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 25.sp)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.Bold, color = Ink)
            Text(sub, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Heading(title: String, sub: String) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(title, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text(sub, fontSize = 12.sp, color = Color.Gray)
    }
}

@Composable
private fun PlanScreen() {
    val plan = listOf(
        "Day 1 • Arrival" to "Check in, relax, explore a nearby beach and watch the sunset.",
        "Day 2 • North Goa" to "Baga, Calangute, Anjuna and a sunset photo stop.",
        "Day 3 • Explore" to "Fort Aguada, local cafés, shopping and group time.",
        "Day 4 • Memories" to "Breakfast, last beach walk and return journey."
    )
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Heading("Trip Plan", "A sample itinerary. Confirm dates and bookings with your group.") }
        itemsIndexed(plan) { i, item ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.size(36.dp).background(Teal.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) {
                        Text("${i + 1}", color = Teal, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(item.first, fontWeight = FontWeight.Bold, color = Ink)
                        Spacer(Modifier.height(5.dp))
                        Text(item.second, color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
        }
        item { Text("These are suggestions, not confirmed reservations or a fixed route.", color = Color.Gray, fontSize = 11.sp) }
    }
}

@Composable
private fun BudgetScreen() {
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var total by remember { mutableIntStateOf(0) }
    val expenses = remember { mutableStateListOf<Pair<String, Int>>() }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Heading("Trip Budget", "Record expenses as your group spends.")
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = DeepTeal)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("TOTAL RECORDED", color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
                Text("₹$total", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                Text("Saved in this app session on this device.", color = Color.White.copy(alpha = .8f), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Expense name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(7.dp))
        OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Amount in ₹") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(7.dp))
        Button(onClick = {
            val n = amount.toIntOrNull()
            if (name.isNotBlank() && n != null && n > 0) {
                expenses.add(name.trim() to n)
                total += n
                name = ""; amount = ""
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Add expense") }
        Spacer(Modifier.height(12.dp))
        Text("RECENT EXPENSES", color = Teal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        if (expenses.isEmpty()) Text("No expenses added yet.", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            itemsIndexed(expenses.reversed()) { _, item ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(item.first); Text("₹${item.second}", color = Teal, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChecklistScreen() {
    val tasks = listOf("Government ID and tickets", "Hotel booking details", "Phone charger and power bank", "Comfortable clothes", "Sunscreen and sunglasses", "Personal medicines", "Reusable water bottle", "Emergency contact details")
    val checked = remember { mutableStateListOf<Boolean>().apply { repeat(tasks.size) { add(false) } } }
    val done = checked.count { it }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Heading("Packing Checklist", "Tick each item as you get it ready.")
        Spacer(Modifier.height(12.dp))
        LinearProgressIndicator(progress = { done.toFloat() / tasks.size }, modifier = Modifier.fillMaxWidth(), color = Teal)
        Text("$done of ${tasks.size} ready", color = Teal, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            itemsIndexed(tasks) { i, task ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked[i], { checked[i] = it })
                        Text(task, modifier = Modifier.weight(1f), color = if (checked[i]) Color.Gray else Ink)
                    }
                }
            }
        }
    }
}
