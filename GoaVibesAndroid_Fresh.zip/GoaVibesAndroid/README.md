# Goa Vibes 2.0

Fresh Android starter for a friends' Goa trip.

Features: Home dashboard, sample itinerary, expense entry and total, packing checklist.

Stack: Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17, Gradle 8.9, Jetpack Compose Material 3.

Important: this first version is a single-device prototype. Expenses and checklist changes are not synced between phones. A truly shared public app needs a backend, user accounts and a database.
